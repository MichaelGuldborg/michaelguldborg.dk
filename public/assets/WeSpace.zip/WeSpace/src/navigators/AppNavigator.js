import { createStackNavigator } from 'react-navigation';

import LoggedOut from '../screens/auth/LoggedOut';
import LoginWithEmail from "../screens/auth/LoginWithEmail";
import LoggedInTabNavigator from "./LoggedInTabNavigator";

import EditProfile from "../screens/EditProfile";

import React from "react";
import RegisterDisplayName from "../screens/auth/RegisterDisplayName";
import RegisterEmail from "../screens/auth/RegisterEmail";
import RegisterPassword from "../screens/auth/RegisterPassword";
import RegisterBirthday from "../screens/auth/RegisterBirthday";
import RegisterTermsAndConditions from "../screens/auth/RegisterTermsAndConditions";
import CreateSpace from "../screens/CreateSpace";
import GlobalChatRoom from "../screens/GlobalChatRoom";
import UpdateEmailAndPassword from "../screens/UpdateEmailAndPassword";
import ViewSpace from "../screens/ViewSpace";


const AppNavigator = createStackNavigator(
    {
        LoggedOut: { screen: LoggedOut },
        RegisterDisplayName: { screen: RegisterDisplayName },
        RegisterEmail: {screen: RegisterEmail},
        RegisterPassword: { screen: RegisterPassword},
        RegisterBirthday: { screen: RegisterBirthday},
        RegisterTermsAndConditions: { screen: RegisterTermsAndConditions},
        LoginWithEmail: { screen: LoginWithEmail },

        LoggedInTabNavigator: {
            screen: LoggedInTabNavigator,
            navigationOptions: {
                header: null,
                gesturesEnabled: false,
            },
        },

        EditProfile: { screen: EditProfile },
        UpdateEmailAndPassword: { screen: UpdateEmailAndPassword},
        CreateSpace: { screen: CreateSpace },
        GlobalChatRoom: { screen: GlobalChatRoom },
        ViewSpace: { screen: ViewSpace },

    },
    {
        initialRouteName: "LoggedOut",
        headerMode: "none"
    }
);

export default AppNavigator;
