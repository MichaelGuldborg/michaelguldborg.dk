import React from 'react';
import { createBottomTabNavigator, createStackNavigator, } from 'react-navigation';

import ExploreContainer from '../containers/ExploreContainer';
import SavedContainer from '../containers/SavedContainer';
import InboxContainer from '../containers/InboxContainer';
import ProfileContainer from '../containers/ProfileContainer';
import SpaceContainer from "../containers/SpaceContainer";

const LoggedInTabNavigator = createBottomTabNavigator({
  Explore: {
    screen: ExploreContainer,
    navigationOptions: {
      tabBarLabel: 'EXPLORE',
      //tabBarIcon: CustomTabBarIcon('ios-search', 22),
    },
  },
  Saved: {
    screen: SavedContainer,
    navigationOptions: {
      tabBarLabel: 'SAVED',
      //tabBarIcon: CustomTabBarIcon('ios-heart-outline', 22),
    },
  },
  Space: {
      screen: SpaceContainer,
      navigationOptions: {
          tabBarLabel: 'SPACES',
          //tabBarIcon: CustomTabBarIcon('ios-heart-outline', 22),
      },
  },
  Inbox: {
    screen: InboxContainer,
    navigationOptions: {
      tabBarLabel: 'INBOX',
      //tabBarIcon: CustomTabBarIcon('ios-ionic', 21),
    },
  },
  Profile: {
    screen: ProfileContainer,
    navigationOptions: {
      tabBarLabel: 'PROFILE',
      //tabBarIcon: CustomTabBarIcon('ios-archive-outline', 25),
    },
  },
}, {
  tabBarOptions: {
    activeTintColor: 'red',
    inactiveTintColor: 'grey',
    labelStyle: {
      fontWeight: '600',
      marginBottom: 5,
    },
    style: {
        backgroundColor: 'white',
        borderTopWidth: 0,
        shadowOffset: { width: 5, height: 3 },
        shadowColor: 'black',
        shadowOpacity: 0.5,
        elevation: 5
    }
  },
  tabBarPosition: 'bottom',
});

export default LoggedInTabNavigator;
