import firebase from '../firebase';

const createChatRoom = (user1, user2) => {
    // TODO
    console.log("CREATE CHAT ROOM");
    console.log("user1.uid : " + user1.uid);
    console.log("user2.uid : " + user2.uid);

}

const listenToChatRoom = (callback) => {

    firebase.database()
        .ref('chatrooms/global/messages')
        .orderByKey()
        .limitToLast(20)
        .on('value', (snapshot) => {

            setTimeout(() => {
                const messages = snapshot.val() || [];

                let array = [];
                Object.values(messages).forEach( (msg) => array.push(msg));

                callback(array);

            }, 0);
        });
};

const sendMessage = (user, text) => {

    if(user === null || text.length < 1) {
        return false
    }

    let message = {
        id: '',
        text: text,
        time: Date.now(),
        author: {
            name: user.displayName,
            avatar: ''
        }
    };

    const newMessageRef = firebase.database()
        .ref('chatrooms/global/messages')
        .push();

    message.id = newMessageRef.key;

    newMessageRef.set(message)
        .catch( (error) => { console.log(error.message) })
};

const ChatRoomService = {
    createChatRoom,
    listenToChatRoom,
    sendMessage
};

export default ChatRoomService;
