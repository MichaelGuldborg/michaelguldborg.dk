import firebase from '../firebase';

const user = {
    email: '',
    password: '',
    displayName: '',

    address: '',
    birthday: '',
}

const signInWithFacebook = async () => {
    //TODO fix so it works
    //TODO - update profile data with data from provider
    const {type,token} = await Expo.Facebook.logInWithReadPermissionsAsync('294097087798772',{ permissions: ['public_profile'] });

    if(type == 'success') {
        const credentials = firebase.auth.FacebookAuthProvider.credential(token);

        firebase.auth().signInWithCredential(credentials)
            .catch((error) => {console.log(error)});
    }
}

const signInWithGoogle = async () => {
    //TODO fix so it works
    //TODO - update profile data with data from provider
    const {type,token} = await Expo.Google.logInWithReadPermissionsAsync('294097087798772',{ permissions: ['public_profile'] });

    if(type == 'success') {
        const credentials = firebase.auth.GoogleAuthProvider.credential(token);

        firebase.auth().signInWithCredential(credentials)
            .catch((error) => {console.log(error)});
    }

}

const createUserWithEmailAndPassword = (email, password) => {
    firebase.auth().createUserWithEmailAndPassword(email, password)
        .catch( (error) => { console.log(error.message) } )
}

const createUserWithUserData = (userData) => {
    firebase.auth().createUserWithEmailAndPassword(userData.email, userData.password)
        .then( () => {

            firebase.auth().currentUser.updateProfile({
                displayName: userData.displayName,
            }).catch( (error) => { console.log(error.message) } )

            updateUserData(userData)
                .catch( (error) => { console.log(error.message) } )


    }).catch( (error) => { console.log(error.message) } )
}

const signInWithEmailAndPassword = async (email, password) => {
    firebase.auth().signInWithEmailAndPassword(email,password)
        .catch( (error) => { console.log(error.message) } )
};

const updateEmailAndPassword = (email, password, newEmail, newPassword) => {

    firebase.auth().signInWithEmailAndPassword(email, password).then( () => {

        firebase.auth().currentUser.updateEmail(newEmail)
            .catch( (error) => { console.log(error.message) } )

        firebase.auth().currentUser.updatePassword(newPassword)
            .catch( (error) => { console.log(error.message) } )

    }).catch( (error) => { console.log(error.message) } )

}

const updateUserProfile = (displayName) => {

    firebase.auth().currentUser.updateProfile({
        displayName: displayName,
    }).catch( (error) => console.log("ERROR UPDATING USER DISPLAY NAME: " + error.message));

}

const updateUserData = (userData) => {

    const user = firebase.auth().currentUser;
    const userDataRef = "/users/" + user.uid + "/data/";

    firebase.database().ref(userDataRef).update({
        "birthday": userData.birthday,
        "address": userData.address,
    }).catch( (error) => { console.log(error.message) } )

}

const deleteUser = (user) => {

    console.log("DELETING USER: " + user.displayName + ", " + user.uid);

    // TODO add reauthentication to delete
    user.delete().then( () => {

        firebase.database().ref("/users/").child(user.uid).remove()
            .catch( (error) => { console.log(error.message) } )

    }).catch( (error) => { console.log(error.message) } )

}



const AuthService = {
    signInWithFacebook,
    signInWithGoogle,
    createUserWithEmailAndPassword,
    createUserWithUserData,
    signInWithEmailAndPassword,
    updateEmailAndPassword,
    updateUserProfile,
    updateUserData,
    deleteUser
};

export default AuthService;
