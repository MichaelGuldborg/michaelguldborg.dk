import firebase from "../firebase"

const createSpace = (size, zipCode, price) => {
    const db = firebase.database();
    const user = firebase.auth().currentUser;

    if(user === null){
        console.log("DATABASE SERVICE: ERROR CREATING SPACE, USER NOT SIGNED IN")
        return
    }

    const userOwnedSpacesPath = "/users/" + user.uid + "/ownedSpaces/";
    const spaceKey = db.ref(userOwnedSpacesPath).push().key;

    db.ref(userOwnedSpacesPath + spaceKey).set({
        "id": spaceKey,
    }).catch((error) => { console.log(error.message) });

    db.ref("/spaces/" + spaceKey).set({
        "id": spaceKey,
        "owner": user.uid,
        "size": size,
        "zipCode": zipCode,
        "price": price,
    }).catch((error) => { console.log(error.message) });

}

const getAllSpaces = (callback) => {

    firebase.database()
        .ref('spaces/')
        .orderByKey()
        .on('value', (snapshot) => {

            const spaces = snapshot.val() || [];

            let array = [];
            Object.values(spaces).forEach( (space) => array.push(space));

            callback(array);

        });
}

const getAllOwnedSpaces = (callback) => {

    const user = firebase.auth().currentUser;

    let spaceKeyList = [];
    let ownedSpaceList = [];

    firebase.database()
        .ref('users/' + user.uid + "/ownedSpaces/")
        .orderByKey()
        .once('value', (snapshot) => {

            const ownedSpacesVal = snapshot.val() || [];

            Object.values(ownedSpacesVal).forEach( (space) => spaceKeyList.push(space.id));

        }).then( () => {

            for (let spaceKey of spaceKeyList) {
                getSpaceByKey(spaceKey, (spaceObject) => {
                    ownedSpaceList.push(spaceObject);
                })
            }

            callback(ownedSpaceList);

    }).catch( (error) => { console.log("ERROR GETTING ALL SPACES: \n" + error.message) } );

}

const getSpaceByKey = (spaceKey, callback) => {

    firebase.database()
        .ref('spaces/' + spaceKey)
        .once('value', (snapshot) => {

            const spaceObject = snapshot.val() || [];

            callback(spaceObject);

        }).catch( (error) => { console.log("ERROR GETTING SPACE WITH ID: " + spaceKey + "\n" + error.message) } )

}


const DatabaseService = {
    createSpace,
    getAllSpaces,
    getAllOwnedSpaces,
    getSpaceByKey,
};

export default DatabaseService;

