import * as firebase from 'firebase';

// should go in a secret file
const config = {
    apiKey: "AIzaSyCnQN9Rc5KJrZqWaD9et0cKH5sqhsIuDd0",
    authDomain: "wespace-58924.firebaseapp.com",
    databaseURL: "https://wespace-58924.firebaseio.com",
    projectId: "wespace-58924",
    storageBucket: "wespace-58924.appspot.com",
    messagingSenderId: "518657706497"
};
firebase.initializeApp(config);

export default firebase;
