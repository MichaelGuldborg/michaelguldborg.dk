import React, { Component } from 'react';
import PropTypes from 'prop-types';
import {
    Text,
    View,
    Image,
    TouchableOpacity,
    TouchableNativeFeedback,
    Platform,
    StyleSheet,
} from 'react-native';
import colors from '../../variables/colors';
import {Card} from "react-native-elements";

export default class FlatListButton extends Component {
    render() {
        const {
            text1,
            text2,
            text3,
            text4,
            disabled,
            textColor,
            background,
            handleOnPress,
            textSize,
            textWeight,
            iconPosition,
            textAlign,
            borderColor,
        } = this.props;
        const backgroundColor = background || 'transparent';
        const color = textColor || colors.black;
        const fontSize = textSize || 18;
        const fontWeight = textWeight || 'normal';
        const alignPosition = textAlign || 'left';
        const iconLocation = iconPosition || 'right';
        const border = borderColor || colors.white;
        const opacityStyle = disabled ? 0.5 : 1;
        const rippleColor = backgroundColor === 'transparent' ? color : 'rgba(0,0,0,0.4)';

        const ButtonComponent = (buttonProps) => {
            if (Platform.OS === 'ios') {
                return (
                    <TouchableOpacity
                        style={[{ opacity: opacityStyle, backgroundColor, borderColor: border }, styles.iosWrapper]}
                        onPress={handleOnPress}
                        activeOpacity={0.6}
                        disabled={disabled}
                    >
                        {buttonProps.children}
                    </TouchableOpacity>
                );
            }
            return (
                <View style={[styles.androidWrapper, {borderColor: border}]}>
                    <TouchableOpacity
                        useForeground={true}
                        onPress={handleOnPress}
                        disabled={disabled}
                        background={TouchableNativeFeedback.Ripple(rippleColor, false)}
                    >
                        <Card style={[{opacity: opacityStyle, backgroundColor, }, styles.androidButtonText]}>
                            {buttonProps.children}
                        </Card>
                    </TouchableOpacity>
                </View>
            );
        };

        return (
            <ButtonComponent>
                <View style={styles.buttonTextWrapper}>
                    <View style={{flex: 1}}>
                        <Text>{text1}</Text>
                        <Text>{text2}</Text>
                    </View>
                    <View style={{flex: 1}}>
                        <Text>{text3}</Text>
                        <Text>{text4}</Text>
                    </View>
                </View>
            </ButtonComponent>
        );
    }
}

FlatListButton.propTypes = {
    zipCode: PropTypes.string,
    size: PropTypes.string,
    price: PropTypes.string,
};



const styles = StyleSheet.create({
    iosWrapper: {
        display: 'flex',
        paddingLeft: 20,
        paddingRight: 20,
        paddingTop: 12,
        paddingBottom: 12,
        marginBottom: 0,
        alignItems: 'center',
    },
    androidWrapper: {
        overflow: 'hidden',
        marginBottom: 0,
    },
    androidButtonText: {
        display: 'flex',
        paddingLeft: 10,
        paddingRight: 10,
        padding: 12,
        paddingBottom: 12,
        alignItems: 'center',
    },
    buttonTextWrapper: {
        flex: 1,
        display: 'flex',
        flexDirection: 'row',
    },
    buttonText: {
        width: '100%',
    },
});
