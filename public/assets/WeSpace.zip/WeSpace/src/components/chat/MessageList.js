import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { FlatList, Image, Text, View } from "react-native";
import moment from 'moment';



export class MessageItem extends Component {

    constructor(props){
        super(props)
    }

    render() {
        const { msg } = this.props;

        return (
            <View style={{flex:1, flexDirection: 'row'}}>
                <View style={{flex:1}}>
                    <Image styleName="small-avatar top"
                           source={{ uri: msg.author.avatar }} />
                </View>
                <View style={{flex:7}}>
                    <View style={{flexDirection: 'row'}}>
                        <Text style={{flex:1}}>{msg.author.name}</Text>
                        <Text style={{flex:1, textAlign: 'right'}}>{moment(msg.time).from(Date.now())}</Text>
                    </View>
                    <Text styleName="multiline">{msg.text}</Text>
                </View>
            </View>
        )}
}

MessageItem.propTypes = {
    msg: PropTypes.object,
};



class MessageList extends Component {

    constructor(props){
        super(props)
    }

    render() {
        const { messages } = this.props;

        return (
            <FlatList
                data={messages}
                keyExtractor={(item, index) => "" + index}
                //selected={this.state.selected}
                renderItem={({item}) => (
                    <MessageItem msg={item}/>
                )}
            />
    )}
}

MessageList.propTypes = {
    messages: PropTypes.array.isRequired,
};


export default MessageList;




