import React, { Component } from 'react';
import PropTypes from 'prop-types';
import colors from "../../variables/colors";
import {Text, TouchableOpacity, View} from "react-native";
import {Input} from "native-base";

class ChatInput extends Component {

    constructor(props){
        super(props)
    }

    render() {
        const { onChangeText, handleSendMessage, } = this.props;

        return (
            <View style={{flex:1, flexDirection: 'row'}}>
                <Input style={{flex:6}}
                       onChangeText={onChangeText}
                       placeholder={"Say something cool..."}/>
                <TouchableOpacity
                    style={{flex:1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.blue}}
                    onPress={handleSendMessage}>
                    <Text>SEND</Text>
                </TouchableOpacity>
            </View>
        )}
}

ChatInput.propTypes = {
    onChangeText: PropTypes.func,
    handleSendMessage: PropTypes.func,
};

export default ChatInput;




