import React, { Component } from "react";
import {StyleSheet, Text, View} from "react-native";
import PropTypes from 'prop-types';
import NavBarButton from "./buttons/NavBarButton";
import colors from "../variables/colors";
import {Icon} from "native-base";

export default class NavBar extends Component {
    constructor(props){
        super(props);

    }

    render() {
        const {
            handleBackButtonPress,
            backgroundColor,
            icon,
            text,
        } = this.props;

        const background = backgroundColor || colors.white;
        const iconColor = (background === colors.white) ?  colors.black : colors.white;
        const backIcon = icon || <Icon name="arrow-back" style={{color: iconColor}}/>;


        return (
            <View style={[styles.wrapper, {backgroundColor: background}]}>
                <View style={[styles.left]}>
                    <NavBarButton
                        handleButtonPress={handleBackButtonPress}
                        icon={backIcon}
                        location="left"
                    />
                </View>

                <View style={[styles.body]}>
                    <Text style={styles.bodyText}>
                        {text}
                    </Text>
                </View>

                <View style={[styles.right]}>

                </View>
            </View>
        );
    }
}

NavBar.propTypes = {
    handleBackButtonPress: PropTypes.func.isRequired,
    backgroundColor: PropTypes.string,
    text: PropTypes.string,
    icon: PropTypes.object,

    location: PropTypes.string,
};

const styles = StyleSheet.create({
    wrapper: {
        flex: 1,
        flexDirection: 'row',
        position: 'absolute',
        left: 0,
        right: 0,
        top: 0,
        marginTop: 23,
        paddingTop: 10,
    },
    left: {
      flex: 2,
      alignItems: 'center',
    },
    body: {
        flex: 10,
        alignItems: 'center',
    },
    bodyText: {
        fontSize: 18,
        fontWeight: '500',
    },
    right: {
      flex: 2,
      alignItems: 'center',
    },
});
