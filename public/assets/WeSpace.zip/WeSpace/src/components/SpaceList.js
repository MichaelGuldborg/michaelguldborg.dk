import React, { Component } from 'react';
import PropTypes from 'prop-types';
import {FlatList, Image, Text, TouchableOpacity, View, TouchableNativeFeedback, StyleSheet, Platform} from "react-native";
import {Card} from "react-native-elements";
import colors from "../variables/colors";
import DatabaseService from "../services/DatabaseService";

export class SpaceItem extends Component {

    navigateToSpaceView() {
        console.log("CLICKED ON SPACE: " + this.props.spaceKey);
        //TODO BULLSHIT SOLUTION !!! NEED TO PASS PROP INSTEAD
        DatabaseService.spaceKey = this.props.spaceKey;
        this.props.navigation.navigate('ViewSpace');
    }


    render() {
        const {
            text1,
            text2,
            text3,
            text4,
        } = this.props;

        const handleOnPress = () => this.navigateToSpaceView();

        const backgroundColor = 'transparent';
        const color = colors.black;
        const fontSize = 18;
        const fontWeight = 'normal';
        const alignPosition = 'left';
        const iconLocation = 'right';
        const border = colors.white;
        const rippleColor = backgroundColor === 'transparent' ? color : 'rgba(0,0,0,0.4)';

        const ButtonComponent = (buttonProps) => {
            if (Platform.OS === 'ios') {
                return (
                    <TouchableOpacity
                        style={[{ backgroundColor, borderColor: border }, styles.iosWrapper]}
                        onPress={handleOnPress}
                        activeOpacity={0.6}
                    >
                        {buttonProps.children}
                    </TouchableOpacity>
                );
            }
            return (
                <View style={[styles.androidWrapper, {borderColor: border}]}>
                    <TouchableOpacity
                        useForeground={true}
                        onPress={handleOnPress}
                        background={TouchableNativeFeedback.Ripple(rippleColor, false)}
                    >
                        <Card style={[{ backgroundColor, }, styles.androidButtonText]}>
                            {buttonProps.children}
                        </Card>
                    </TouchableOpacity>
                </View>
            );
        };

        return (
            <ButtonComponent>
                <View style={styles.buttonTextWrapper}>
                    <View style={{flex: 1}}>
                        <Text>{text1}</Text>
                        <Text>{text2}</Text>
                    </View>
                    <View style={{flex: 1}}>
                        <Text>{text3}</Text>
                        <Text>{text4}</Text>
                    </View>
                </View>
            </ButtonComponent>
        );
    }
}

SpaceItem.propTypes = {
    spaceKey: PropTypes.string,
    text1: PropTypes.string,
    text2: PropTypes.string,
    text3: PropTypes.string,
    text4: PropTypes.string,

};


class SpaceList extends Component {

    constructor(props){
        super(props)
    }

    render() {
        const { navigation, data } = this.props;

        return (
            <FlatList
                data={data}
                keyExtractor={(item, index) => "" + index}
                renderItem={({item}) =>
                    <SpaceItem
                        navigation={ navigation }
                        spaceKey={item.id}
                        text1={"Size: " + item.size}
                        text2={"Zipcode: " + item.zipCode}
                        text3={" "}
                        text4={"Price: " + item.price}
                        owner={item.owner}/>}
            />
        )}
}

SpaceList.propTypes = {
    navigation: PropTypes.object.isRequired,
    data: PropTypes.array.isRequired,
};

const styles = StyleSheet.create({
    iosWrapper: {
        display: 'flex',
        paddingLeft: 20,
        paddingRight: 20,
        paddingTop: 12,
        paddingBottom: 12,
        marginBottom: 0,
        alignItems: 'center',
    },
    androidWrapper: {
        overflow: 'hidden',
        marginBottom: 0,
    },
    androidButtonText: {
        display: 'flex',
        paddingLeft: 10,
        paddingRight: 10,
        padding: 12,
        paddingBottom: 12,
        alignItems: 'center',
    },
    buttonTextWrapper: {
        flex: 1,
        display: 'flex',
        flexDirection: 'row',
    },
    buttonText: {
        width: '100%',
    },
});


export default SpaceList;




