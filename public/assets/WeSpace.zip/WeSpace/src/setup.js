import * as Expo from "expo";
import React from "react";
import AppNavigator from "./navigators/AppNavigator";
import {Text} from "react-native";


export default class Setup extends React.Component {
  constructor() {
    super();
    this.state = {
      isReady: false
    };
  }
  componentWillMount() {
    console.ignoredYellowBox = ['Setting a timer']; //to ignore firebase and react-native timer error in development
    this.loadFonts().catch( (error) => {console.log(error.message)});
  }

  async loadFonts() {
    await Expo.Font.loadAsync({
      Roboto: require("native-base/Fonts/Roboto.ttf"),
      Roboto_medium: require("native-base/Fonts/Roboto_medium.ttf"),
      Ionicons: require("@expo/vector-icons/fonts/Ionicons.ttf")
    });
    this.setState({ isReady: true });
  }

  render() {
    if (!this.state.isReady) {
        return <Text>Loading</Text>;
    }
    return (
        <AppNavigator />
    );
  }
}
