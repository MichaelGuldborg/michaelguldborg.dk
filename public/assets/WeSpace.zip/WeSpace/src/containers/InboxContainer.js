import React from 'react';
import {View, Text, ScrollView, KeyboardAvoidingView, FlatList, TouchableOpacity} from "react-native";
import styles from "./styles";
import {Input} from "native-base";
import MessageList from "../components/chat/MessageList";
import firebase from "../firebase";
import ChatRoomService from "../services/ChatRoomService";
import {KeyboardAwareScrollView} from "react-native-keyboard-aware-scroll-view";
import colors from "../variables/colors";
import FullWidthButton from "../components/buttons/FullWidthButton";

export default class InboxContainer extends React.Component {

    constructor(props){
        super(props);


    }


    handleGlobalChat() {
        const { navigation } = this.props;
        navigation.navigate('GlobalChatRoom');
    }

    render() {
        return (
            <View style={styles.scrollViewWrapper}>
                <ScrollView style={styles.scrollView}>
                    <Text style={styles.header}>
                        Inbox
                    </Text>

                    <FullWidthButton
                        text="GLOBAL CHAT"
                        handleOnPress={() => this.handleGlobalChat()}
                    />
                </ScrollView>
            </View>
        );
    }


}

/*
RENDER OLD

           <View style={styles.scrollViewWrapper}>
                <TouchableOpacity
                    onPress={() => this.sendMessage()}>
                    <Text style={styles.header}>
                        Global ChatRoom
                    </Text>
                </TouchableOpacity>
                <KeyboardAwareScrollView style={styles.scrollView}>
                    <MessageList messages={this.state.messages}/>

                    <View style={{flex:1, flexDirection: 'row'}}>
                        <ChatInput style={{flex:6}}
                            onChangeText={(text) => this.setState({ text: text })}
                            placeholder={"Say something cool..."}
                            onSubmit/>
                        <TouchableOpacity
                            style={{flex:1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.blue}}>
                            <Text>SEND</Text>
                        </TouchableOpacity>
                    </View>
                    <Text>Can not see me1</Text>
                    <Text>Can not see me2</Text>

                </KeyboardAwareScrollView>
            </View>
 */



/*
SCROLL FUNTIONS
    componentDidMount() {
        this.scrollToBottom(false);
    }

    componentDidUpdate() {
        this.scrollToBottom();
    }

    onScrollViewLayout = (event) => {
        const layout = event.nativeEvent.layout;

        this.setState({
            scrollViewHeight: layout.height
        });
    }

    onInputLayout = (event) => {
        const layout = event.nativeEvent.layout;

        this.setState({
            inputHeight: layout.height
        });
    }

    scrollToBottom(animate = true) {
        const { scrollViewHeight, inputHeight } = this.state,
            { chatHeight } = this.props;

        const scrollTo = chatHeight - scrollViewHeight + inputHeight;

        if (scrollTo > 0) {
            this.refs.scroll.scrollToPosition(0, scrollTo, animate)
        }
    }

    _scrollToInput(reactRef) {
        //this.refs.scroll.scrollToFocusedInput(ReactNative.findNodeHandle(reactRef));
    }
 */
