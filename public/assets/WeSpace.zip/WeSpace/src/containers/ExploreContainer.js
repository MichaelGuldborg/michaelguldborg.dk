import React from 'react';
import {View, Text, ScrollView, TouchableOpacity} from "react-native";
import styles from "./styles";
import colors from "../variables/colors";
import firebase from "../firebase";
import SpaceList from "../components/SpaceList";
import DatabaseService from "../services/DatabaseService";

export default class ExploreContainer extends React.Component {

    constructor(props){
        super(props);
        this.state = {
            data: [],
        }


        DatabaseService.getAllSpaces( (spacesList) => {
            this.setState({data: spacesList});
        })

    }

    debugButtonPress() {
        console.log("Button pressed in explore container");
        console.log(this.state.data);

    }

    handleButtonPress() {

        //create renter owner chat

        const owner = "owner";

        const user = firebase.auth().currentUser;

        const userThreadPath = "/users/" + user.uid + "/threads/";
        const ownerThreadPath = "/users/" + owner + "/threads/";
        const threadPath = "/threads/";

        const threadKey = firebase.database().ref(userThreadPath).push().key;


        console.log("userThreadPath: " + userThreadPath);
        console.log("ownerThreadPath: " + ownerThreadPath);
        console.log("threadPath: " + threadPath);
        console.log("threadKey: " + threadKey);




    }


    render() {
        const { navigation } = this.props;

        return (
            <View style={styles.scrollViewWrapper}>

                <TouchableOpacity
                    onPress={() => this.debugButtonPress()}>
                    <Text style={styles.header}>
                        Explore Container
                    </Text>
                </TouchableOpacity>

                <ScrollView style={styles.scrollView}>


                    <SpaceList
                        navigation={navigation}
                        data={this.state.data}/>


                </ScrollView>
            </View>
        );
    }
}
