import React from 'react';
import {View, Text, ScrollView, TouchableOpacity } from "react-native";
import CardButton from "../components/buttons/CardButton";
import styles from "./styles";
import colors from "../variables/colors";
import DatabaseService from "../services/DatabaseService";
import SpaceList from "../components/SpaceList";

export default class SpaceContainer extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            ownedSpaceList: [],
        };


        DatabaseService.getAllOwnedSpaces( (ownedSpaceList) => {
            this.setState({
                ownedSpaceList: ownedSpaceList,
            })
        })


    }

    render() {
        const { navigation } = this.props;

        return (
            <View style={styles.scrollViewWrapper}>
                <ScrollView style={styles.scrollView}>
                    <Text style={styles.header}>
                        Manage your spaces
                    </Text>
                    <CardButton
                        text={"Create Space"}
                        handleOnPress={() => navigation.navigate("CreateSpace")}/>

                    <SpaceList
                        navigation={navigation}
                        data={this.state.ownedSpaceList}/>



                </ScrollView>
            </View>
        );
    }
}

