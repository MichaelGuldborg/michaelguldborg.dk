import React from 'react';
import {View, Text, ScrollView} from "react-native";
import styles from "./styles";
import colors from "../variables/colors";

export default class StatusContainer extends React.Component {

    constructor(props){
        super(props);
    }

    render() {
        return (
            <View style={styles.scrollViewWrapper}>
                <ScrollView style={styles.scrollView}>
                    <Text style={styles.header}>
                        Status Container
                    </Text>
                </ScrollView>
            </View>
        );
    }
}
