import { StyleSheet } from 'react-native';
import colors from "../variables/colors";

let termsTextSize = 13;
let headingTextSize = 30;

const styles = StyleSheet.create({
    scrollViewWrapper: {
        backgroundColor: colors.white,
        flex: 1,
        padding: 0,
        position: 'absolute',
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
    },
    scrollView: {
        paddingTop: 23,
        flex: 1,
    },
    header: {
        fontSize: headingTextSize,
        color: colors.gray04,
        fontWeight: '500',
        marginTop: 40,
        marginBottom: 40,
        paddingLeft: 20,
    },
    profileView: {
        backgroundColor: colors.gray01,
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        height: 140,
    },
});

export default styles;
