import React from 'react';
import {Button, View, Text, StyleSheet, ScrollView, TouchableOpacity, TouchableHighlight, FlatList} from "react-native";
import {Alert, Modal} from "react-native";
import {Container, Form, Icon, Input, Item, Label} from "native-base"
import * as firebase from 'firebase';
import DatabaseService from "../services/DatabaseService";
import FullWidthButton from "../components/buttons/FullWidthButton";
import styles from "./styles";
import AuthService from "../services/AuthService";

export default class ProfileContainer extends React.Component {

    constructor(props){
        super(props);

        this.state = {
            modalVisible: false,
            email: '',
            password: '',
        };

    }

    setModalVisible(visible) {
        this.setState({modalVisible: visible});
    }

    handleLogout = () => {
        firebase.auth().signOut().catch( (error) => console.log(error));
        this.props.navigation.navigate("LoggedOut");
    };

    handleDeleteAccount = () => {
        let accountDeleted = false;
        const user = firebase.auth().currentUser;
        let needCredential = false;
        user.delete().then( () => {
            AuthService.deleteUser(user);
            accountDeleted = true;
            this.props.navigation.navigate("LoggedOut");
        }).catch((error) => {
            // Re-authentication
            // https://firebase.google.com/docs/auth/web/manage-users#re_authenticate_a_user
            console.log("Credential needed");
            this.setModalVisible(!this.state.modalVisible);
        });
    };

    reAuthenticate = () => {
        let credential = firebase.auth.EmailAuthProvider.credential(this.state.email, this.state.password);
        firebase.auth().currentUser.reauthenticateAndRetrieveDataWithCredential(credential).then(() => {
            // Re-authentication was a success
            this.deleteAccount();
        }).catch(function(error) {
            // Re-authentication was not a success
            console.log(error);
        });
    };


    render() {
        return (
            <View style={styles.scrollViewWrapper}>
                <ScrollView style={styles.scrollView}>
                    <TouchableOpacity
                        style={styles.profileView}
                        onPress={ () => this.props.navigation.navigate("EditProfile") }>
                        <Text>{firebase.auth().currentUser.displayName}</Text>
                        <Text style={{color: "grey"}}>Rediger profil</Text>
                    </TouchableOpacity>

                    <FullWidthButton
                        text="Logout"
                        handleOnPress={() => this.handleLogout()}
                    />
                    <FullWidthButton
                        text="Delete account"
                        handleOnPress={() => this.handleDeleteAccount()}
                    />


                    {/* Re-Authentication */}
                    <View style={{marginTop: 22}}>
                        <Modal
                            animationType="slide"
                            transparent={false}
                            visible={this.state.modalVisible}
                            onRequestClose={() => {
                                alert('Modal has been closed.');
                            }}>
                            <View style={{paddingTop: 20, height: 60}}>
                                <TouchableOpacity
                                    style={styles.button}
                                    onPress={() => this.setModalVisible(!this.state.modalVisible)}>
                                    <Text>Back</Text>
                                </TouchableOpacity>
                            </View>
                            <Form>
                                <Item floatingLabel>
                                    <Label>Email</Label>
                                    <Input
                                        autocorret={false}
                                        autoCapitalize="none"
                                        onChangeText={(email) => this.setState({birthday:email})}
                                    />
                                </Item>
                                <Item floatingLabel>
                                    <Label>Password</Label>
                                    <Input
                                        secureTextEntry={this.state.hidden}
                                        autocorret={false}
                                        autoCapitalize="none"
                                        onChangeText={(password) => this.setState({password:password})}
                                    />
                                </Item>
                                <TouchableOpacity style={styles.button} onPress={() => this.reAuthenticate()}>
                                    <Text>Delete Account</Text>
                                </TouchableOpacity>
                            </Form>
                        </Modal>
                    </View>
                </ScrollView>
            </View>


        );
    }
}
