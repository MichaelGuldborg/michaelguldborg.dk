import React from 'react';
import {Button, StyleSheet, Text, View, ScrollView, TouchableOpacity, KeyboardAvoidingView} from 'react-native';
import firebase from '../firebase';

import RoundedButton from "../components/buttons/RoundedButton";
import InputField from "../components/form/InputField";
import colors from "../variables/colors";
import styles from "./styles";
import DatePicker from "react-native-datepicker";
import FullWidthButton from "../components/buttons/FullWidthButton";
import NavBar from "../components/NavBar";
import AuthService from "../services/AuthService";


export default class EditProfile extends React.Component {

    constructor(props){
        super(props);

        const user = firebase.auth().currentUser;

        this.state = {
            firstName: user.displayName.split(" ")[0],
            lastName: user.displayName.split(" ")[1],
            email: user.email,
            newPassword: '',
            birthday: '',
            password: '',
            sessionId: '',
            hidden: true,
        };


        const dataRef = firebase.database().ref('/users/' + user.uid + "/data/");
        dataRef.once('value').then( (snapshot) => {
            const databaseMap = snapshot.val();
            this.setState({birthday: databaseMap['birthday']});
        });


    }

    handleConfirmPress() {
        const { firstName, lastName, birthday} = this.state;
        const displayName = firstName + " " + lastName;

        const userData = {
            birthday: birthday,
            address: '',
        }

        AuthService.updateUserProfile(displayName);
        AuthService.updateUserData(userData);

        this.props.navigation.navigate('LoggedInTabNavigator');
    }


    render() {
        const { navigation } = this.props;
        const { firstName, lastName, email, birthday } = this.state;

        return (
            <KeyboardAvoidingView
                style={[styles.wrapper]}
                behavior="padding"
            >
                <NavBar
                    text={"Edit Profile"}
                    handleBackButtonPress={() => navigation.goBack()}/>

                <View style={styles.scrollViewWrapper}>
                    <ScrollView style={styles.scrollView}>
                        <InputField
                            labelText="Firstname"
                            defaultValue={firstName}
                            labelTextSize={14}
                            labelColor={colors.black}
                            textColor={colors.black}
                            borderBottomColor={colors.black}
                            inputType="text"
                            customStyle={{ marginBottom: 30 }}
                            onChangeText={(firstName) => this.setState({firstName: firstName})}
                            showCheckmark={false}
                        />
                        <InputField
                            labelText="Lastname"
                            defaultValue={lastName}
                            labelColor={colors.black}
                            textColor={colors.black}
                            borderBottomColor={colors.black}
                            inputType="text"
                            customStyle={{ marginBottom: 30 }}
                            onChangeText={(lastName) => this.setState({lastName: lastName})}
                            showCheckmark={false}
                        />

                        <Text style={{fontSize: 14, fontWeight: '700', marginBottom: 10}}>
                            Birthday
                        </Text>

                        <View style={[{marginBottom: 30,}, styles.datePickerWrapper]}>
                            <DatePicker
                                customStyles={{dateInput:{borderWidth: 0}}}
                                showIcon={false}
                                style={styles.datePicker}
                                date={birthday}
                                mode="date"
                                format="YYYY-MM-DD"
                                minDate="1920-01-01"
                                maxDate="2018-01-01"
                                confirmBtnText="Confirm"
                                cancelBtnText="Cancel"
                                onDateChange={(birthday) => this.setState({birthday: birthday})}
                            />
                        </View>

                        <Text style={{fontSize: 14, fontWeight: '700', marginBottom: 10}}>
                            Email
                        </Text>
                        <Text style={{fontSize: 14, fontWeight: 'normal', marginBottom: 10}}>
                            {email}
                        </Text>


                        <FullWidthButton
                            text={'Change Email And Password'}
                            handleOnPress={() => navigation.navigate('UpdateEmailAndPassword')}/>

                        <RoundedButton
                            text={"Confirm"}
                            borderColor={colors.black}
                            handleOnPress={() => this.handleConfirmPress()}/>
                        <RoundedButton
                            text={"Cancel"}
                            borderColor={colors.black}
                            handleOnPress={() => navigation.goBack()}/>

                        <View style={{height:30}}/>

                    </ScrollView>
                </View>
            </KeyboardAvoidingView>
        );
    }

}
