import React from 'react';
import {Button, Text, View, ScrollView, KeyboardAvoidingView} from 'react-native';
import DatabaseService from "../services/DatabaseService"
import InputField from "../components/form/InputField";
import RoundedButton from "../components/buttons/RoundedButton";
import colors from "../variables/colors";
import styles from "./styles";
import NavBar from "../components/NavBar";

export default class CreateSpace extends React.Component {

    constructor(props){
        super(props);
        this.state = {
            size: '',
            zipCode: '',
            price: '',

        }
    }

    async handleSizeChange(size){
        this.setState({ size: size});
    }

    async handleZipCodeChange(zipCode){
        this.setState({ zipCode: zipCode});
    }

    async handlePriceChange(price){
        this.setState({ price: price});
    }

    handleConfirmPress() {
        const { size, zipCode, price } = this.state;

        DatabaseService.createSpace(size, zipCode, price);

        //TODO USER SUCCESS FEEDBACK
        this.props.navigation.goBack();

    };

    handleCancelPress() {
        const {navigation} = this.props;
        navigation.goBack();
    }

    render() {
        const {navigation} = this.props;

        return (
            <KeyboardAvoidingView
                style={[styles.wrapper]}
                behavior="padding"
            >
                <NavBar
                    handleBackButtonPress={() => navigation.goBack()}/>

                <View style={styles.scrollViewWrapper}>
                    <ScrollView style={styles.scrollView}>
                        <Text style={styles.header}>
                            Create Space
                        </Text>
                        <InputField
                            labelText="Size"
                            labelTextSize={14}
                            labelColor={colors.black}
                            textColor={colors.black}
                            borderBottomColor={colors.black}
                            inputType="numeric"
                            customStyle={{ marginBottom: 30 }}
                            onChangeText={(size) => this.handleSizeChange(size)}
                            showCheckmark={false}
                            autoFocus
                        />
                        <InputField
                            labelText="ZipCode"
                            labelTextSize={14}
                            labelColor={colors.black}
                            textColor={colors.black}
                            borderBottomColor={colors.black}
                            inputType="decimal-pad"
                            customStyle={{ marginBottom: 30 }}
                            onChangeText={(zipCode) => this.handleZipCodeChange(zipCode)}
                            showCheckmark={false}
                        />
                        <InputField
                            labelText="Price/month"
                            labelTextSize={14}
                            labelColor={colors.black}
                            textColor={colors.black}
                            borderBottomColor={colors.black}
                            inputType="number-pad"
                            customStyle={{ marginBottom: 30 }}
                            onChangeText={(price) => this.handlePriceChange(price)}
                            showCheckmark={false}
                        />
                        <RoundedButton
                            text={"Confirm"}
                            borderColor={colors.black}
                            handleOnPress={() => this.handleConfirmPress()}/>
                        <RoundedButton
                            text={"Cancel"}
                            borderColor={colors.black}
                            handleOnPress={() => this.handleCancelPress()}/>

                    </ScrollView>
                </View>
            </KeyboardAvoidingView>
        );
    }
}



/*

class Comment extends React.Component {
    state = {
        text: '',
        height: 25
    };

    onTextChange(event) {
        const { contentSize, text } = event.nativeEvent;

        this.setState({
            text: text,
            height: contentSize.height > 100 ? 100 : contentSize.height
        });
    }

    render() {
        return (
            <TextInput
                multiline={true}
                style={{ height: this.state.height }}
                onChange={this.onTextChange.bind(this)}
                value={this.state.text}
            />
        );
    }
}

<Container>
                <ScrollView>
                    <Form>
                        <Item floatingLabel>
                            <Label>Address</Label>
                            <ChatInput
                                onChangeText={(address) => this.setState({address: address})}/>
                        </Item>
                        <Item floatingLabel>
                            <Label>Price</Label>
                            <ChatInput
                                onChangeText={(price) => this.setState({price: price})}/>
                        </Item>
                        <Item floatingLabel>
                            <Label>Size</Label>
                            <ChatInput
                                onChangeText={(size) => this.setState({size: size})}/>
                        </Item>
                        <Picker
                            selectedValue = {this.state.type}
                            onValueChange = {(type) => this.setState({type: type})}>
                            <Picker.Item label="Storage Type 1" value="st1" />
                            <Picker.Item label="Storage Type 2" value="st2" />
                            <Picker.Item label="Storage Type 3  " value="st3" />
                        </Picker>
                        <Item floatingLabel>
                            <Label>Description</Label>
                            <ChatInput
                                onChangeText={(description) => this.setState({description: description})}/>
                        </Item>
                        <Button
                            title="Create Space"
                            onPress={() => this.createSpace()} />
                        <Button
                            title="Cancel"
                            onPress={() => this.props.navigation.goBack() }/>
                    </Form>
                </ScrollView>
            </Container>
*/
