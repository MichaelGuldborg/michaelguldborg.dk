import React from 'react';
import {
    View,
} from 'react-native';
import firebase from '../firebase';

import colors from "../variables/colors";
import styles from "./styles";
import {KeyboardAwareScrollView} from "react-native-keyboard-aware-scroll-view";
import MessageList from "../components/chat/MessageList";
import ChatRoomService from "../services/ChatRoomService";
import ChatInput from "../components/chat/ChatInput";
import NavBar from "../components/NavBar";

export default class GlobalChatRoom extends React.Component {

    constructor(props){
        super(props);

        this.state = {
            messages: [],
            scrollViewHeight: 0,
            inputHeight: 0,
        };

        ChatRoomService.listenToChatRoom( (array) => {
            this.setState({messages: array});
        });

    }

    sendMessage() {
        const user = firebase.auth().currentUser;
        const { text } = this.state;

        ChatRoomService.sendMessage(user, text);
        //TODO remove text from inputfield

    };

    render() {
        const { navigation } = this.props;

        return (
            <View style={styles.wrapper}>

                <NavBar
                    handleBackButtonPress={() => navigation.goBack()}/>


                <KeyboardAwareScrollView style={styles.scrollViewWrapper}>
                    <View style={{flex: 10}}>
                        <MessageList
                            messages={this.state.messages}/>
                    </View>

                    <ChatInput
                        style={{flex:1}}
                        onChangeText={(text) => this.setState({ text: text })}
                        handleSendMessage={() => this.sendMessage()}/>


                </KeyboardAwareScrollView>
            </View>

        );
    }
}


/*



 */
