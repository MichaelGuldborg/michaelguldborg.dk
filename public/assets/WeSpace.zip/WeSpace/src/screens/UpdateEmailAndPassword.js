import React from 'react';
import {Button, StyleSheet, Text, View, ScrollView, TouchableOpacity, KeyboardAvoidingView} from 'react-native';

import RoundedButton from "../components/buttons/RoundedButton";
import InputField from "../components/form/InputField";
import colors from "../variables/colors";
import styles from "./styles";
import AuthService from "../services/AuthService";
import NavBar from "../components/NavBar";


export default class EditProfile extends React.Component {

    constructor(props){
        super(props);

        this.state = {
            email: '',
            password: '',
            newEmail: '',
            newPassword: '',
            newPasswordCheck: '',
        };

    }


    handleConfirmPress() {
        const { navigation } = this.props;
        const { email, password, newEmail, newPassword, newPasswordCheck } = this.state;

        if(newPassword === newPasswordCheck && newPassword.length > 4){
            if(newEmail) {

                //TODO - user feedback on success
                AuthService.updateEmailAndPassword(email, password, newEmail, newPassword);
                navigation.goBack();

            }

        }else {
            //TODO - user feedback on failed password criteria
            console.log("PASSWORD NOT CHANGED BECAUSE OF INEQUAL OR LENGHT")
        }

    }


    render() {
        const { navigation } = this.props;

        return (
            <KeyboardAvoidingView
                style={[styles.wrapper]}
                behavior="padding"
            >
                <NavBar
                    text={"Change Password"}
                    handleBackButtonPress={() => navigation.goBack()}/>

                <View style={styles.scrollViewWrapper }>
                    <ScrollView style={styles.scrollView}>


                        <InputField
                            labelText="Email"
                            labelTextSize={14}
                            labelColor={colors.black}
                            textColor={colors.black}
                            borderBottomColor={colors.black}
                            inputType="email-address"
                            customStyle={{ marginBottom: 30 }}
                            onChangeText={(email) => this.setState({email: email})}
                            showCheckmark={false}
                        />

                        <InputField
                            labelText="Password"
                            labelTextSize={14}
                            labelColor={colors.black}
                            textColor={colors.black}
                            borderBottomColor={colors.black}
                            inputType="password"
                            customStyle={{ marginBottom: 30 }}
                            onChangeText={(password) => this.setState({password: password})}
                            showCheckmark={false}
                        />

                        <InputField
                            labelText="New Email"
                            labelTextSize={14}
                            labelColor={colors.black}
                            textColor={colors.black}
                            borderBottomColor={colors.black}
                            inputType="email-address"
                            customStyle={{ marginBottom: 30 }}
                            onChangeText={(newEmail) => this.setState({newEmail: newEmail})}
                            showCheckmark={false}
                        />

                        <InputField
                            labelText="New Password"
                            labelTextSize={14}
                            labelColor={colors.black}
                            textColor={colors.black}
                            borderBottomColor={colors.black}
                            inputType="password"
                            disableHideButton={true}
                            customStyle={{ marginBottom: 30 }}
                            onChangeText={(newPassword) => this.setState({newPassword: newPassword})}
                            showCheckmark={false}
                        />

                        <InputField
                            labelText="Re-Enter New Password"
                            labelTextSize={14}
                            labelColor={colors.black}
                            textColor={colors.black}
                            borderBottomColor={colors.black}
                            inputType="password"
                            disableHideButton={true}
                            customStyle={{ marginBottom: 30 }}
                            onChangeText={(newPasswordCheck) => this.setState({newPasswordCheck: newPasswordCheck})}
                            showCheckmark={false}
                        />

                        <RoundedButton
                            text={"Confirm"}
                            borderColor={colors.black}
                            handleOnPress={() => this.handleConfirmPress()}/>
                        <RoundedButton
                            text={"Cancel"}
                            borderColor={colors.black}
                            handleOnPress={() => navigation.goBack()}/>

                        <View style={{height:30}}/>


                    </ScrollView>
                </View>
            </KeyboardAvoidingView>
        );
    }

}
