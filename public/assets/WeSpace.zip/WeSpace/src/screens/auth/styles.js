import { StyleSheet } from 'react-native';
import colors from '../../variables/colors';

let termsTextSize = 13;
let headingTextSize = 30;

const styles = StyleSheet.create({
  wrapper: {
    flex: 1,
    display: 'flex',
    backgroundColor: colors.green01,
  },
  scrollViewWrapper: {
    marginTop: 70,
    flex: 1,
    padding: 0,
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
  },
  scrollView: {
    paddingLeft: 30,
    paddingRight: 30,
    paddingTop: 20,
    flex: 1,
  },
  header: {
    fontSize: headingTextSize,
    color: colors.white,
    fontWeight: '300',
    marginBottom: 40,
  },
  notificationWrapper: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
  },
  welcomeWrapper: {
      flex: 1,
      display: 'flex',
      marginTop: 30,
      padding: 20,
  },
  providerButtonIcon: {
      color: colors.green01,
      position: 'relative',
      left: 20,
      zIndex: 8,
  },
  logo: {
      width: 50,
      height: 50,
      marginTop: 50,
      marginBottom: 40,
  },
  moreOptionsButton: {
      marginTop: 10,
  },
  moreOptionsButtonText: {
      color: colors.white,
      fontSize: 16,
  },
  termsAndConditions: {
      flexWrap: 'wrap',
      alignItems: 'flex-start',
      flexDirection: 'row',
      marginTop: 30,
  },
  termsText: {
      color: colors.white,
      fontSize: termsTextSize,
      fontWeight: '600',
  },
  linkButton: {
      borderBottomWidth: 1,
      borderBottomColor: colors.white,
  },
  datePickerWrapper: {
      flex: 1,
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
  },
  datePicker: {
      width: 200,
      backgroundColor: colors.white,
      borderColor: colors.white,
  },
});

export default styles;
