import React from 'react';
import {Text, View, ScrollView, TouchableOpacity, KeyboardAvoidingView} from 'react-native';
import { Auth } from '../../services/AuthService'

import InputField from '../../components/form/InputField';
import NextArrowButton from "../../components/buttons/NextArrowButton";
import styles from "./styles";
import colors from "../../variables/colors";
import Loader from "../../components/Loader";
import AuthService from "../../services/AuthService";
import NavBar from "../../components/NavBar";

// TODO: Use formik or Redux for form validation
export default class LoginWithEmail extends React.Component {

    constructor(props){
        super(props);
        this.state = {
            formValid: true,
            validEmail: false,
            email: '',
            password: '',
            validPassword: false,
            loadingVisible: false,
        };
    }


    handleNextButton() {
        // Todo - Loading state and error handling for invalid user cred
        //this.setState({ loadingVisible: true });
        const { email, password } = this.state;

        this.handleLogin(email, password)
    }

    handleLogin(email, password) {
        AuthService.signInWithEmailAndPassword(email, password);
    };

    handleCloseNotification() {
        this.setState({ formValid: true });
    }

    handleEmailChange(email) {
        const emailCheckRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        const { validEmail } = this.state;
        this.setState({ email: email });

        if (!validEmail) {
            if (emailCheckRegex.test(email)) {
                this.setState({ validEmail: true });
            }
        } else if (!emailCheckRegex.test(email)) {
            this.setState({ validEmail: false });
        }

    }

    handlePasswordChange(password) {
        const { validPassword } = this.state;
        this.setState({ password });

        if (!validPassword) {
            if (password.length > 4) {
                this.setState({ validPassword: true });
            }
        } else if (password <= 4) {
            this.setState({ validPassword: false });
        }

    }

    render() {
        const {
            formValid, loadingVisible, validEmail, validPassword,
        } = this.state;
        const isNextButtonDisabled = !( validEmail && validPassword);
        const showNotification = !formValid;
        const background = formValid ? colors.green01 : colors.darkOrange;
        const notificationMarginTop = showNotification ? 10 : 0;
        return (
            <KeyboardAvoidingView
                style={[styles.wrapper, { backgroundColor: colors.green01 }]}
                behavior="padding"
            >

                <NavBar
                    handleBackButtonPress={() => this.props.navigation.goBack()}
                    backgroundColor={colors.green01}/>


                <View style={styles.scrollViewWrapper}>
                    <ScrollView style={styles.scrollView}>
                        <Text style={styles.header}>
                            Log In
                        </Text>
                        <InputField
                            labelText="EMAIL ADDRESS"
                            labelTextSize={14}
                            labelColor={colors.white}
                            textColor={colors.white}
                            borderBottomColor={colors.white}
                            inputType="email-address"
                            customStyle={{ marginBottom: 30 }}
                            onChangeText={(email) => this.handleEmailChange(email)}
                            showCheckmark={validEmail}
                            autoFocus
                        />
                        <InputField
                            labelText="PASSWORD"
                            labelTextSize={14}
                            labelColor={colors.white}
                            textColor={colors.white}
                            borderBottomColor={colors.white}
                            inputType="password"
                            customStyle={{ marginBottom: 30 }}
                            onChangeText={(password) => this.handlePasswordChange(password)}
                            showCheckmark={validPassword}
                        />
                    </ScrollView>
                    <NextArrowButton
                        handleNextButton={() => this.handleNextButton()}
                        disabled={ isNextButtonDisabled }
                    />
                </View>
                <Loader
                    modalVisible={loadingVisible}
                    animationType="fade"
                />
                <View style={[styles.notificationWrapper, { marginTop: notificationMarginTop }]}>

                </View>
            </KeyboardAvoidingView>
        );
    }
}
