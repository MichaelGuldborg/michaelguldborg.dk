import React from 'react';
import {Text, View, ScrollView, KeyboardAvoidingView} from 'react-native';

import InputField from '../../components/form/InputField';
import NextArrowButton from "../../components/buttons/NextArrowButton";
import styles from "./styles";
import colors from "../../variables/colors";

import DatabaseService from "../../services/DatabaseService";
import NavBar from "../../components/NavBar";

// TODO: Use formik or Redux for form validation
export default class RegisterDisplayName extends React.Component {

    constructor(props){
        super(props);
        this.state = {
            firstName: '',
            lastName: '',
            validFirstName: false,
            validLastName: false,
        };
    }

    handleNextButton() {
        const { navigation } = this.props;
        const { firstName, lastName } = this.state;

        DatabaseService.firstName = firstName;
        DatabaseService.lastName = lastName;

        navigation.navigate("RegisterEmail");
    }

    handleFirstNameChange(firstName) {
        const { validFirstName } = this.state;
        this.setState({ firstName: firstName });

        //could be shorter code but this is more compute efficient
        if (!validFirstName) {
            if(firstName.length > 0){
                this.setState({ validFirstName: true });
            }
        } else if (firstName.length < 0){
            this.setState({ validFirstName: false });
        }
    }

    handleLastNameChange(lastName) {
        const { validLastName } = this.state;
        this.setState({ lastName: lastName });

        if (!validLastName) {
            if(lastName.length > 0){
                this.setState({ validLastName: true });
            }
        } else if (lastName.length < 0){
            this.setState({ validLastName: false });
        }
    }

    render() {
        const {
            validFirstName, validLastName,
        } = this.state;
        const isNextButtonDisabled = !( validFirstName && validLastName);
        return (
            <KeyboardAvoidingView
                style={[styles.wrapper, { backgroundColor: colors.green01 }]}
                behavior="padding"
            >
                <NavBar
                    handleBackButtonPress={() => this.props.navigation.goBack()}
                    backgroundColor={colors.green01}/>

                <View style={styles.scrollViewWrapper}>
                    <ScrollView style={styles.scrollView}>
                        <Text style={styles.header}>
                            What is your name?
                        </Text>
                        <InputField
                            labelText="First Name"
                            labelTextSize={14}
                            labelColor={colors.white}
                            textColor={colors.white}
                            borderBottomColor={colors.white}
                            inputType="text"
                            customStyle={{ marginBottom: 30 }}
                            onChangeText={(firstName) => this.handleFirstNameChange(firstName)}
                            showCheckmark={validFirstName}
                            autoFocus
                        />
                        <InputField
                            labelText="Last Name"
                            labelTextSize={14}
                            labelColor={colors.white}
                            textColor={colors.white}
                            borderBottomColor={colors.white}
                            inputType="text"
                            customStyle={{ marginBottom: 30 }}
                            onChangeText={(lastName) => this.handleLastNameChange(lastName)}
                            showCheckmark={validLastName}
                        />
                    </ScrollView>
                    <NextArrowButton
                        handleNextButton={() => this.handleNextButton()}
                        disabled={ isNextButtonDisabled }
                    />
                </View>
            </KeyboardAvoidingView>
        );
    }
}
