import React from 'react';
import {Text, View, ScrollView, KeyboardAvoidingView} from 'react-native';

import InputField from '../../components/form/InputField';
import NextArrowButton from "../../components/buttons/NextArrowButton";
import styles from "./styles";
import colors from "../../variables/colors";

import DatabaseService from "../../services/DatabaseService";
import NavBar from "../../components/NavBar";

// TODO: Use formik or Redux for form validation
export default class RegisterPassword extends React.Component {

    constructor(props){
        super(props);
        this.state = {
            password: '',
            validPassword: false,
        };
    }

    handleNextButton() {
        const { navigation } = this.props;
        const { password } = this.state;
        DatabaseService.password = password;
        navigation.navigate("RegisterBirthday");
    }

    handlePasswordChange(password) {
        const { validPassword } = this.state;
        this.setState({ password });

        if (!validPassword) {
            if (password.length > 4) {
                this.setState({ validPassword: true });
            }
        } else if (password <= 4) {
            this.setState({ validPassword: false });
        }

    }

    render() {
        const {
            validPassword,
        } = this.state;
        const isNextButtonDisabled = !( validPassword );
        return (
            <KeyboardAvoidingView
                style={[styles.wrapper, { backgroundColor: colors.green01 }]}
                behavior="padding"
            >
                <NavBar
                    handleBackButtonPress={() => this.props.navigation.goBack()}
                    backgroundColor={colors.green01}/>

                <View style={styles.scrollViewWrapper}>
                    <ScrollView style={styles.scrollView}>
                        <Text style={styles.header}>
                            Choose a password
                        </Text>
                        <InputField
                            labelText="PASSWORD"
                            labelTextSize={14}
                            labelColor={colors.white}
                            textColor={colors.white}
                            borderBottomColor={colors.white}
                            inputType="password"
                            customStyle={{ marginBottom: 30 }}
                            onChangeText={(password) => this.handlePasswordChange(password)}
                            showCheckmark={validPassword}
                            autoFocus
                        />
                    </ScrollView>
                    <NextArrowButton
                        handleNextButton={() => this.handleNextButton()}
                        disabled={ isNextButtonDisabled }
                    />
                </View>
            </KeyboardAvoidingView>
        );
    }
}
