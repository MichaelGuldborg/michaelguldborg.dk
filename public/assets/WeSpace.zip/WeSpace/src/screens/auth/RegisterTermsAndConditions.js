import React from 'react';
import {Text, View, ScrollView, KeyboardAvoidingView, TouchableOpacity} from 'react-native';

import RoundedButton from "../../components/buttons/RoundedButton";

import DatabaseService from "../../services/DatabaseService"
import AuthService from "../../services/AuthService";

import colors from "../../variables/colors";
import styles from "./styles";
import NavBar from "../../components/NavBar";

// TODO: Use formik or Redux for form validation
export default class RegisterTermsAndConditions extends React.Component {

    constructor(props){
        super(props);
        this.state = {
            accepted: false,
        };
    }

    async handleAccept() {
        const {navigation} = this.props;
        const {email, password, firstName, lastName, birthday} = DatabaseService;

        const userData = ({
            email: email,
            password: password,
            displayName: firstName + " " + lastName,
            birthday: birthday,
            address: '',
        });

        console.log("creating user with")
        console.log(userData)

        AuthService.createUserWithUserData(userData);

    }

    handleDecline() {
        const { navigation } = this.props;
        console.log("Declined Terms");
        navigation.goBack();
    }

    render() {
        return (
            <KeyboardAvoidingView
                style={[styles.wrapper, { backgroundColor: colors.green01 }]}
                behavior="padding"
            >
                <NavBar
                    handleBackButtonPress={() => this.props.navigation.goBack()}
                    backgroundColor={colors.green01}/>

                <View style={styles.scrollViewWrapper}>
                    <ScrollView style={styles.scrollView}>
                        <Text style={styles.header}>
                            Accept Terms And Conditions
                        </Text>

                        <RoundedButton
                            text="Accept"
                            textColor={colors.white}
                            handleOnPress={() => this.handleAccept()}
                        />

                        <RoundedButton
                            text="Decline"
                            textColor={colors.white}
                            handleOnPress={() => this.handleDecline()}
                        />

                    </ScrollView>
                </View>
            </KeyboardAvoidingView>
        );
    }

}
