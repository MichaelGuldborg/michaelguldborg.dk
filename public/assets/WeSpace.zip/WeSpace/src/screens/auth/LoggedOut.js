import React from 'react';
import {StyleSheet, View, ScrollView, TouchableOpacity, Text} from "react-native";
import {Container} from "native-base"
import * as firebase from 'firebase';
import RoundedButton from "../../components/buttons/RoundedButton";
import Icon from 'react-native-vector-icons/FontAwesome';
import colors from "../../variables/colors";
import styles from "./styles";
import AuthService from "../../services/AuthService";


// TODO: Use formik or Redux for form validation
export default class LoggedOut extends React.Component {

    constructor(props){
        super(props);
        this.state = {
            email: '',
            password: '',
            sessionId: '',
            hidden: true,
        }
    }

    componentDidMount(){

        firebase.auth().onAuthStateChanged((user) => {
            if(user){
                console.log("LOGGEDOUT: user is logged in");
                this.props.navigation.navigate("LoggedInTabNavigator");
            }else {
                console.log("LOGGEDOUT: user is logged in");
                this.props.navigation.navigate("LoggedOut");
            }
        })
    }

    async handleFacebookLogin(){
        await AuthService.signInWithFacebook();
    };

    async handleGoogleLogin(){
        await AuthService.signInWithGoogle();
    };

    async handleEmailLogin(){
        this.props.navigation.navigate('LoginWithEmail');
    }

    async handleCreateAccount(){
        this.props.navigation.navigate('RegisterDisplayName');
    }


    render() {
        return (
            <ScrollView style={styles.wrapper}>
                <View style={styles.welcomeWrapper}>
                    <Text style={styles.header}>
                        Welcome to WeSpace
                    </Text>
                </View>
                <RoundedButton
                    text="Facebook"
                    textColor={colors.green01}
                    background={colors.white}
                    icon={<Icon name="facebook" size={20} style={styles.providerButtonIcon} />}
                    handleOnPress={() => this.handleFacebookLogin()}
                />
                <RoundedButton
                    text="Google"
                    textColor={colors.green01}
                    background={colors.white}
                    icon={<Icon name="google" size={20} style={styles.providerButtonIcon} />}
                    handleOnPress={() => this.handleGoogleLogin()}
                />
                <RoundedButton
                    text="Email"
                    textColor={colors.green01}
                    background={colors.white}
                    //icon={<Icon name="facebook" size={20} style={styles.providerButtonIcon} />}
                    handleOnPress={() => this.handleEmailLogin()}
                />
                <RoundedButton
                    text="Create Account"
                    textColor={colors.white}
                    handleOnPress={() => this.handleCreateAccount()}
                />
            </ScrollView>
            );
    }
}
