import React from 'react';
import {Text, View, ScrollView, KeyboardAvoidingView} from 'react-native';

import NextArrowButton from "../../components/buttons/NextArrowButton";
import DatePicker from 'react-native-datepicker'
import styles from "./styles";
import colors from "../../variables/colors";
import DatabaseService from "../../services/DatabaseService";
import NavBar from "../../components/NavBar";

export default class RegisterBirthday extends React.Component {

    constructor(props){
        super(props);
        this.state = {
            date: '',
            validDate: true,
        };
    }

    handleNextButton() {
        const { navigation } = this.props;
        const { date } = this.state;

        DatabaseService.birthday = date;

        navigation.navigate("RegisterTermsAndConditions");
    }

    handleDateChange(date) {
        const { validDate } = this.state;
        this.setState({ date: date });

    }

    render() {
        const { validDate } = this.state;
        const isNextButtonDisabled = !( validDate );

        return (
            <KeyboardAvoidingView
                style={[styles.wrapper, { backgroundColor: colors.green01 }]}
                behavior="padding"
            >
                <NavBar
                    handleBackButtonPress={() => this.props.navigation.goBack()}
                    backgroundColor={colors.green01}/>

                <View style={styles.scrollViewWrapper}>
                    <ScrollView style={styles.scrollView}>
                        <Text style={styles.header}>
                            What is your birthday?
                        </Text>
                        <View style={styles.datePickerWrapper}>
                            <DatePicker
                                customStyles={{dateInput:{borderWidth: 0}}}
                                showIcon={false}
                                style={styles.datePicker}
                                date={this.state.date}
                                mode="date"
                                format="YYYY-MM-DD"
                                minDate="1920-01-01"
                                maxDate="2018-01-01"
                                confirmBtnText="Confirm"
                                cancelBtnText="Cancel"
                                onDateChange={(date) => this.handleDateChange(date)}
                            />
                        </View>
                    </ScrollView>
                    <NextArrowButton
                        handleNextButton={() => this.handleNextButton()}
                        disabled={ isNextButtonDisabled }
                    />
                </View>
            </KeyboardAvoidingView>
        );
    }
}

