import React from 'react';
import {Text, View, ScrollView, KeyboardAvoidingView} from 'react-native';

import InputField from '../../components/form/InputField';
import NextArrowButton from "../../components/buttons/NextArrowButton";
import styles from "./styles";
import colors from "../../variables/colors";

import DatabaseService from "../../services/DatabaseService";
import NavBar from "../../components/NavBar";

// TODO: Use formik or Redux for form validation
export default class RegisterEmail extends React.Component {

    constructor(props){
        super(props);
        this.state = {
            email: '',
            validEmail: false,
        };
    }

    handleNextButton() {
        const { navigation } = this.props;
        const { email } = this.state;
        DatabaseService.email = email;

        navigation.navigate("RegisterPassword");
    }

    handleEmailChange(email) {
        const emailCheckRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        const { validEmail } = this.state;
        this.setState({ email: email });

        if (!validEmail) {
            if (emailCheckRegex.test(email)) {
                this.setState({ validEmail: true });
            }
        } else if (!emailCheckRegex.test(email)) {
            this.setState({ validEmail: false });
        }

    }

    render() {
        const {
            validEmail,
        } = this.state;
        const isNextButtonDisabled = !( validEmail );
        return (
            <KeyboardAvoidingView
                style={[styles.wrapper, { backgroundColor: colors.green01 }]}
                behavior="padding"
            >
                <NavBar
                    handleBackButtonPress={() => this.props.navigation.goBack()}
                    backgroundColor={colors.green01}/>

                <View style={styles.scrollViewWrapper}>
                    <ScrollView style={styles.scrollView}>
                        <Text style={styles.header}>
                            What is your email?
                        </Text>
                        <InputField
                            labelText="Email"
                            labelTextSize={14}
                            labelColor={colors.white}
                            textColor={colors.white}
                            borderBottomColor={colors.white}
                            inputType="email-address"
                            customStyle={{ marginBottom: 30 }}
                            onChangeText={(email) => this.handleEmailChange(email)}
                            showCheckmark={validEmail}
                            autoFocus
                        />
                    </ScrollView>
                    <NextArrowButton
                        handleNextButton={() => this.handleNextButton()}
                        disabled={ isNextButtonDisabled }
                    />
                </View>
            </KeyboardAvoidingView>
        );
    }
}
