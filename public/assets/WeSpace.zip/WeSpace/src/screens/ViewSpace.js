import React from 'react';
import PropTypes from 'prop-types';
import {Button, StyleSheet, Text, View, ScrollView, TouchableOpacity, KeyboardAvoidingView} from 'react-native';

import colors from "../variables/colors";
import styles from "./styles";
import NavBar from "../components/NavBar";
import DatabaseService from "../services/DatabaseService";


export default class ViewSpace extends React.Component {

    constructor(props){
        super(props);

        this.state = {
            isLoading: true,
            space: {
                price: 10,
                zipCode: 10,
                id: 'id',
                size: 10,
            }
        }


    }

    componentDidMount() {
        //TODO BULLSHIT SOLUTION !!! NEED TO PASS PROP INSTEAD
        const spaceKey = DatabaseService.spaceKey;


        if( spaceKey !== undefined ) {
            DatabaseService.getSpaceByKey(spaceKey, (spaceObject) => {
                this.setState({
                    space: spaceObject,
                    isLoading: false,
                })
            })
        }else {
            console.log("VIEWSPACE: SPACEKEY PROPS WAS: " + spaceKey)
        }


    }


    render() {
        const { navigation } = this.props;
        const { zipCode, price, id, size} = this.state.space;
        const { isLoading } = this.state;

        return (
            <KeyboardAvoidingView
                style={[styles.wrapper]}
                behavior="padding"
            >
                <NavBar
                    text={"View Space"}
                    handleBackButtonPress={() => navigation.goBack()}/>

                <View style={styles.scrollViewWrapper}>
                    <ScrollView style={styles.scrollView}>

                        <Text>{isLoading}</Text>

                        <Text>{zipCode}</Text>

                        <Text>{price}</Text>

                        <Text>{id}</Text>

                        <Text>{size}</Text>

                    </ScrollView>
                </View>
            </KeyboardAvoidingView>
        );
    }
}

ViewSpace.propTypes = {
    spaceKey: PropTypes.string,
}
