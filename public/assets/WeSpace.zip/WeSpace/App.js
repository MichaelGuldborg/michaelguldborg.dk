import React from "react";
import Setup from "./src/setup";

export default class App extends React.Component {
    render() {
        return <Setup />;
    }
}
